# FHE


##Random Shit/Notes

Cool stuff to do:


FHE notes:
Bootstrappable: can decrypt its own decryption scheme

Encrypt: PT -> E -> E -> E .... d times
Decrypt: CT

Given: D(E(sk,C, inp)) = C(inp) when C = D
or when D = D + 1 level of NAND gate

Idea: homomorphic decrpytion (cool stuff)
secret key pk1: encrypt cipher text values
secret key pk2: encrypt pk1

DH: given g^a and g^b, compute g^ab

Under group mod p:
