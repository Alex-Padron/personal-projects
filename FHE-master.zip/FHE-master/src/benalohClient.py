

class benalohEncryption(EncryptedRequest):

	def makeURLQuery(self, ctxts):
		return "x1=" + ctxts[0] + "&am=" + ctxts[1]

	def initialize(self, keySize):
		pass

	def encrypt(self, message):
		pass

	def decrypt(self, message):
		pass



BH = benalohEncryption()

print('Welcome to the super secure adder thing')
print("")

#query the user for key size and initialize EG based on that 
size = input('Enter the number of bits you want to use as a key: ')
BH.initialize(size)

print("")
print("Finished generating a key")
print("")

#get the ip addr and query values from the user
ipAddr = input('Enter the IP to send requests to: ')
print("")
a = input('Type the first number you want multiplied: ')
b = input('Type the second number you want multiplied: ')
print("")

#generate the two encryptions
c1 = BH.encrypt(a)
c2 = BH.encrypt(b)

#form the cipher text array from the encryption outputs
ctxts = [None] * 2
ctxts[0] = c1
ctxts[1] = c2

#send the http request
result = EG.sendHTTPRequest(ipAddr, ctxts)

#decrypt and print the decryption result
print("")
print("The decrypted result is: " + str(BH.decrypt(result)))
print("")