import sympy.polys.domains as poly

ff = poly.FiniteField(2**2)
ff.inject()
print(ff)