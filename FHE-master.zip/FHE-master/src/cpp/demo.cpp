#include <NTL/ZZ.h>
#include "FHE.h"
#include "timing.h"
#include "EncryptedArray.h"
#include <NTL/lzz_pXFactoring.h>

#include <cassert>
#include <cstdio>


int main(){
	long k = 1000; //security parameter
	long c = 2; //number of columns in key switching matricies 
	long p = 2; //plaintext base
	long d = 1; //degree of the field extension
	long s = 0; //minimum number of slots
	long chosen_m = 0; //I think this means we just use the m that we get from FindM
	long R = 1;
	long r = 1; //"lifing" whatever this means
	//get L based on R and r
    long L = 3*R+3;
    if (p>2 || r>1) { // add some more primes for each round
      long addPerRound = 2*ceil(log((double)p)*r*3)/(log(2.0)*FHE_p2Size) +1;
      L += R * addPerRound;
    }

	long m = FindM(k, L, c, p, d, s, chosen_m, true);

	vector<long> gens;
	vector<long> ords;

	//actually start doing stuff here, make the context for FHE to work in
	FHEcontext context(m, p, r, gens, ords);

	//probably important, idk what it does though
	buildModChain(context, L, c);

	//got ourselves a secret key
	FHESecKey secretKey(context);
	//and I guess we got ourselves a public key as well
	const FHEPubKey& publicKey = secretKey;
	//generate the secret part for only the secret key, not the constant public key
	long w = 64; //hamming weight of the secret key
	secretKey.GenSecKey(w);

	//no idea what this does
	ZZX G;
  	if (d == 0)
    	G = context.alMod.getFactorsOverZZ()[0];
  	else
    	G = makeIrredPoly(p, d); 

    //compute key switching matricies for secret key
    addSome1DMatrices(secretKey);

    //get our encrypted array
    EncryptedArray ea(context, G);
	long nslots = ea.size();

	//make some plain text
  	NewPlaintextArray pt1(ea);

	std::vector<long> array(150);
	array[0] = 0;
	array[1] = 3; 
  	encode(ea, pt1, array);  //pt = 1
	std::cout << "Encrypting with plaintext: " << pt1 << std::endl;


  	//make a cipher text based on the public key
  	Ctxt ct1(publicKey);
  	ea.encrypt(ct1, publicKey, pt1); //encrypt stuff



  	//now we are going to make some new values to add and multiply with
  	NewPlaintextArray pt2(ea);
  	array[0] = 1;
  	array[1] = 2; 
  	encode(ea, pt2, array);  //conts1 = 3
	std::cout << "Encrypting with plaintext: " << pt2 << std::endl;

  	Ctxt ct2(publicKey);
  	ea.encrypt(ct2, publicKey, pt2);

  	//std::cout << "Adding ciphertexts: " << ct1 << " and " << ct2 << std::endl << std::endl;
  	//ct1.addConstant(ct2);
  	ct1 *= ct2;
  	//store the output of the decryption
  	NewPlaintextArray output(ea);
  	ea.decrypt(ct1, secretKey, output);
  	std::cout << "got decryped result: " << output << std::endl;
}