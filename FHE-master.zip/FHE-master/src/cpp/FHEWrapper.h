#ifndef _FHE_H_
#define _FHE_H_

#define k 100
/*
	long k = 100; //security parameter
	long c = 2; //number of columns in key switching matricies 
	long p = 2; //plaintext base
	long d = 1; //degree of the field extension
	long s = 0; //minimum number of slots
	long chosen_m = 0; //I think this means we just use the m that we get from FindM
	long R = 1;
	long r = 1; //"lifing" whatever this means
*/

class FHEWrapper {

	FHEWrapper();
	~FHEWrapper();

};

#endif