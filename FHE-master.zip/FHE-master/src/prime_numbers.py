from Crypto.Util import number

n_length = 20

primeNum = number.getPrime(n_length)

print(primeNum)

import os
from Crypto.PublicKey import ElGamal
message = "Hello"

key = ElGamal.generate(20, os.urandom)

print(key)

print(key.y, key.g, key.p)

print("%5.3f" % key.y)
print("%5.3f" % key.g)
print("%5.3f" % key.p)