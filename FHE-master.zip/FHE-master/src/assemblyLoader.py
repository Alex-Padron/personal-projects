"""
Code to load the assembly from a text file and parse in into an array of instructions to send homomorphically

Instructions are as follows:
LD(mem location (not encrypted), register (not encrypted))
ST(mem location (not encrypted), register (not encrypted))
ADD(register1 (not encrypted), register2 (not encrypted), register3 (not encrypted))
SUB(register1 (not encrypted), register2 (not encrypted), register3 (not encrypted))
MUL(register1 (not encrypted), register2 (not encrypted), register3 (not encrypted))
DIV(register1 (not encrypted), register2 (not encrypted), register3 (not encrypted))
SET(register1 (not encrypted), value (encrypted))
JMP(register1 (not encrypted), regiser2(not encrypted)) //here register1 is the conditional, and register 2 is the final destination
"""


"""
Class representing an enumeration of the assembly instructions
"""
from enum import Enum
class Operations(Enum):
    LD = 1
    ST = 2
    ADD = 3
    SUB = 4
    SET = 5
    DIV = 6
    JMP = 7
    MUL = 8



class Loader():

    def __init__(self):
        pass

    def load(self, fileName):
        instructions = []

        with open(fileName) as f:
            lines = f.readlines()

        for i in range(len(lines)):
            line = lines[i]
            instr = line.split("(")[0]

            values = [int(s) for s in line.split() if s.isdigit()]
            op = [Operations[instr], values[0], values[1]] 

            if (instr == "ADD" or instr == "SUB" or instr == "MUL" or instr == "DIV"):
                op.append(values[2])

            instructions.append(op) 


        
        return instructions

