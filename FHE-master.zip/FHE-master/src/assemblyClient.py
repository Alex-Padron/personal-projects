from assemblyLoader import Operations, Loader
from Crypto.PublicKey import ElGamal
from paillier import *
import os
import requests



"""
Implementation of the EncryptedRequest class that uses El Gamal homomorphic encryption.
"""
class assemblyClient():

	def __init__(self, ip_addr, keySize):
		self.KeyLen = keySize

		self.programCounter = 0

		self.Program = []

		self.elGamal = ElGamal.generate(self.KeyLen, os.urandom)

		priv, pub = generate_keypair(keySize)
		self.paillier = (priv, pub)

		self.IP = ip_addr

	def load(self, filename):
		LD = Loader()
		self.Program = LD.load(filename)
		print("Program is now set to: ", self.Program)

	def encryptCode(self):
		for operation in self.Program:
			print(operation)
			if operation[0] == Operations.SET:
				operation[2] = encrypt(self.paillier[1], operation[2])
				#self.Program[index] = operation

	def sendCode(self):
		payload = {Program: self.Program, ProgramCounter: self.ProgramCounter}
		response = requests.put("http://" + str(self.IP) + "/assembly/sendCode", data=payload)

		if response.content == "SUCCESS":
			self.requestRegisters()



	def sendCommands(self):
		#loop while we have not exited the program
		while self.programCounter < len(self.Program):
			reply = self.sendOperation(self.Program[self.programCounter])

		return self.requestRegisters()


	"""
	Method to send a single operation to the server
	"""
	def sendOperation(self, operation):
		print(operation)
		opcode = str(operation[0]).split(".")[1]
		if (opcode == "SET" ):
			#encrypt under adding by default
			ctxt = encrypt(self.paillier[1], operation[2])
			url = "http://" + str(self.IP) + "/assembly/" + opcode + "/?r1=" + str(operation[1]) + "&r2=" + str(ctxt)
			result = requests.get(url).content
		else:
			url = "http://" + str(self.IP) + "/assembly/" + opcode + "/?r1=" + str(operation[1]) + "&r2=" + str(operation[2])
			print('Sending request: ' + url)
			result = requests.get(url).content

		self.programCounter += 1

	"""
	Method called once we are done sending commands from assembly.
	it returns a list of the register contents that can be decrypted
	"""
	def requestRegisters():
		print("requesting registers from server")
		url = "http://" + str(self.IP) + "/assembly/" + "requestRegisters/"
		print('Sending request: ' + url)
		return requests.get(url).content




print('Welcome to the super secure homomorphic assembly thing')
print("")

#query the user for key size and initialize EG based on that 
size = input('Enter the number of bits you want to use as a key: ')

#get the ip addr and query values from the user
ipAddr = input('Enter the IP to send requests to: ')
print("")

AC = assemblyClient(ipAddr, size)

print("")
print("Finished generating keys")
print("")

AC.load("assembly.txt")

AC.encryptCode()

print("")
print("The encrypted code is: ", AC.Program)
print("")
result = AC.sendCommands()

print("The resulting registers are: ", result)